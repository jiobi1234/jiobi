from fastapi import APIRouter, HTTPException, Query, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import Optional
from app.api.auth import get_current_user
from app.services.theme_service import ThemeService
from app.models.theme_models import (
    CreateThemeRequest,
    UpdateThemeRequest,
    ThemeResponse,
    ThemesResponse
)

router = APIRouter()
security = HTTPBearer()
theme_service = ThemeService()

# 서비스 인스턴스는 함수 내부에서 생성 (순환 import 방지)

@router.get("/refresh-section/")
async def refresh_section(
    section_type: str = Query(..., description="섹션 타입"),
    limit: int = Query(6, description="제한 개수")
):
    """섹션 데이터 새로고침"""
    from app.services.tour_service import TourService
    tour_service = TourService()
    try:
        result = await tour_service.refresh_section(section_type, limit)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/search")
async def search_places(
    keyword: Optional[str] = Query(None, description="검색 키워드"),
    page: int = Query(1, description="페이지 번호"),
    limit: int = Query(10, description="페이지당 개수"),
    region: Optional[str] = Query(None, description="시도 (예: 서울, 경기)"),
    district: Optional[str] = Query(None, description="구/군 (예: 강남구, 수원시)")
):
    """장소 검색"""
    from app.services.place_service import PlaceService
    place_service = PlaceService()
    try:
        # 키워드나 지역 중 하나는 필수
        if not keyword and not region and not district:
            raise HTTPException(status_code=400, detail="검색 키워드 또는 지역을 입력해주세요.")
        
        result = await place_service.search_places(
            keyword or "", 
            page, 
            limit, 
            region, 
            district
        )
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/place/{place_id}")
async def get_place_detail(place_id: str):
    """장소 상세 정보"""
    from app.services.place_service import PlaceService
    place_service = PlaceService()
    try:
        result = await place_service.get_place_detail(place_id)
        if not result:
            raise HTTPException(status_code=404, detail="Place not found")
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/theme/{theme_name}")
async def get_theme_places(
    theme_name: str,
    page: int = Query(1, description="페이지 번호"),
    limit: int = Query(10, description="페이지당 개수")
):
    """테마별 장소 조회"""
    from app.services.tour_service import TourService
    tour_service = TourService()
    try:
        result = await tour_service.get_theme_places(theme_name, page, limit)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/plan")
async def create_plan(plan_data: dict):
    """여행 계획 생성"""
    from app.services.tour_service import TourService
    tour_service = TourService()
    try:
        result = await tour_service.create_plan(plan_data)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/plan/{plan_id}")
async def get_plan(plan_id: str):
    """여행 계획 조회"""
    from app.services.tour_service import TourService
    tour_service = TourService()
    try:
        result = await tour_service.get_plan(plan_id)
        if not result:
            raise HTTPException(status_code=404, detail="Plan not found")
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/plans")
async def get_user_plans(
    user_id: Optional[str] = Query(None, description="사용자 ID"),
    page: int = Query(1, description="페이지 번호"),
    limit: int = Query(10, description="페이지당 개수")
):
    """사용자 여행 계획 목록"""
    from app.services.tour_service import TourService
    tour_service = TourService()
    try:
        result = await tour_service.get_user_plans(user_id, page, limit)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/themes", response_model=ThemeResponse)
async def create_theme(
    theme_data: CreateThemeRequest,
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """테마 생성 (관리자만)"""
    try:
        payload = get_current_user(credentials)
        user_id = payload.get("user_id")
        
        # 사용자 이메일 가져오기
        from app.services.auth_service import AuthService
        auth_service = AuthService()
        user = await auth_service.get_current_user(user_id)
        
        return await theme_service.create_theme(theme_data, user.email)
    except PermissionError as e:
        raise HTTPException(status_code=403, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/themes", response_model=ThemesResponse)
async def get_themes():
    """테마 목록 조회"""
    try:
        return await theme_service.get_themes()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/themes/{theme_id}", response_model=ThemeResponse)
async def get_theme(theme_id: str):
    """특정 테마 조회"""
    try:
        return await theme_service.get_theme(theme_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/themes/{theme_id}")
async def update_theme(
    theme_id: str,
    theme_data: UpdateThemeRequest,
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """테마 수정 (관리자만)"""
    try:
        payload = get_current_user(credentials)
        user_id = payload.get("user_id")
        
        # 사용자 이메일 가져오기
        from app.services.auth_service import AuthService
        auth_service = AuthService()
        user = await auth_service.get_current_user(user_id)
        
        return await theme_service.update_theme(theme_id, theme_data, user.email)
    except PermissionError as e:
        raise HTTPException(status_code=403, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/themes/{theme_id}")
async def delete_theme(
    theme_id: str,
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """테마 삭제 (관리자만)"""
    try:
        payload = get_current_user(credentials)
        user_id = payload.get("user_id")
        
        # 사용자 이메일 가져오기
        from app.services.auth_service import AuthService
        auth_service = AuthService()
        user = await auth_service.get_current_user(user_id)
        
        return await theme_service.delete_theme(theme_id, user.email)
    except PermissionError as e:
        raise HTTPException(status_code=403, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

